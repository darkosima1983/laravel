@extends("layout")

@section ("title")
    Über uns
@endsection

@section ("content")
    <p>Ovo je About stranica</p>
@endsection

