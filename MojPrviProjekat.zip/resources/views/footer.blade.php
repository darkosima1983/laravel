   <!-- Footer -->
    <footer class="text-center">
        <div class="container">
            <p>&copy; {{ date('Y') }} UhrenShop. Alle Rechte vorbehalten.</p>
            <p>
                <a href="{{ url('/about') }}">Über uns</a> | 
                <a href="{{ url('/contact') }}">Kontakt</a>
            </p>
        </div>
    </footer>