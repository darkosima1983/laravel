

<?php $__env->startSection("title"); ?>
    Shop
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($product); ?>

         <?php if(in_array($product, [
                "Casio G-Shock Classic",
                "Casio Vintage Edgy"
            ])): ?>
                <strong> - Aktion!</strong>
            <?php endif; ?>
        </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make("layout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\itmentorstva\laravel\MojPrviProjekat\resources\views/shop.blade.php ENDPATH**/ ?>