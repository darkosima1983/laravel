

<?php $__env->startSection("title"); ?>
    Über uns
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <p>Ovo je About stranica</p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\itmentorstva\laravel\MojPrviProjekat\resources\views/about.blade.php ENDPATH**/ ?>