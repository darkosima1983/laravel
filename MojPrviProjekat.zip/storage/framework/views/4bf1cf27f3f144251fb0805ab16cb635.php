   <!-- Footer -->
    <footer class="text-center">
        <div class="container">
            <p>&copy; <?php echo e(date('Y')); ?> UhrenShop. Alle Rechte vorbehalten.</p>
            <p>
                <a href="<?php echo e(url('/about')); ?>">Über uns</a> | 
                <a href="<?php echo e(url('/contact')); ?>">Kontakt</a>
            </p>
        </div>
    </footer><?php /**PATH C:\xampp\htdocs\itmentorstva\laravel\MojPrviProjekat\resources\views/footer.blade.php ENDPATH**/ ?>