<?php $__env->startSection("title"); ?>
    Startseite
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Hero sekcija -->
    <div class="p-5 mb-4 bg-light rounded-3" 
         style="background: url('https://images.unsplash.com/photo-1519744346365-9f2f0e69fdd1') center/cover no-repeat; min-height: 70vh; display: flex; align-items: center; justify-content: center; color: white; text-shadow: 2px 2px 6px rgba(0,0,0,0.7);">
        <div class="text-center">
           <h1 class="shop-title">Willkommen in unserem Online Uhren Shop</h1>
            <p class="shop-subtitle">Exklusive Uhren für jeden Anlass – Stil, Eleganz und Qualität an einem Ort.</p>
            <p class="shop-subtitle">aktuelle Uhrzeit <?php echo e($trenutnoVreme); ?></p>
            <?php if($trenutniSat <= 12): ?>
                <p class="shop-subtitle">Guten Morgen!</p>
            <?php elseif($trenutniSat < 18): ?>
                <p class="shop-subtitle">Guten Tag!</p>
            <?php else: ?>
                <p class="shop-subtitle">Guten Abend!</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Sekcija ispod hero -->
    <div class="container text-center my-5">
        <h2>Warum bei uns kaufen?</h2>
        <div class="row mt-4">
            <div class="col-md-4">
                <h4>✔ Qualität</h4>
                <p>Alle unsere Uhren sind sorgfältig ausgewählt und stammen von renommierten Marken.</p>
            </div>
            <div class="col-md-4">
                <h4>✔ Schnelle Lieferung</h4>
                <p>Ihre Bestellung wird schnell und sicher direkt zu Ihnen nach Hause geliefert.</p>
            </div>
            <div class="col-md-4">
                <h4>✔ Kundenservice</h4>
                <p>Unser Team ist jederzeit für Sie da und hilft bei allen Fragen rund um die Uhr.</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("layout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\itmentorstva\laravel\MojPrviProjekat\resources\views/welcome.blade.php ENDPATH**/ ?>